from contact_storage import save_contacts, load_contacts

def add_contacts(name, email, phone, address):
    contacts = load_contacts()
    contact = {
        "name": name,
        "email": email,
        "phone": phone,
        "address": address,
        'status': 'pending'
    }
    contacts.append(contact)
    save_contacts(contacts)
    
def view_contacts():
    contacts = load_contacts()
    print("\nContact list: \n")
    for i, contact in enumerate(contacts, start = 1):
        print(f"{i}. Name: {contact['name']}, Email: {contact['email']}, Phone number: {contact['phone']}, Address: {contact['address']}")
def remove_contact(index):
    contacts = load_contacts()
    if 0<index<=len(contacts):
        del contacts[index-1]
        save_contacts(contacts)
    else:
        print("Invalid index!")
def search_contacts(query):
    contacts = load_contacts()
    results = []
    for contact in contacts:
        if query.lower() in contact['name'].lower() or query.lower() in contact['email'].lower():
            results.append(contact)
    print("\nSearch results: ")
    for i, contact in enumerate(contacts, start = 1):
        print(f"{i}. Name: {contact['name']}, Email: {contact['email']}, Phone number: {contact['phone']}, Address: {contact['address']}")
def update_contact(index):
    contacts = load_contacts()
    if 0<index<=len(contacts):
        contacts[index-1]['status'] = "Completed"
        save_contacts(contacts)
    else:
        print("Invalid index!")