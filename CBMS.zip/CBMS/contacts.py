from contact_manager import add_contacts, view_contacts, remove_contact, search_contacts, update_contact

while True:
    print("\n\nContact Book Management System!")
    print("1. Add contact")
    print("2. View contact")
    print("3. Remove contact")
    print("4. Search contact")
    print("5. Update contact")
    print("6. Exit")

    choice = input("Please choose a number: ")

    if choice == "1":
        name = input("Enter a name: ")
        email = input(f"Enter {name}'s Email: ")
        phone = int(input(f"Enter {name}'s phone number: "))
        address = input(f"Enter {name}'s address: ")
        add_contacts(name, email, phone, address)
        print("Contact added successfully.")
    elif choice == "2":
        view_contacts()
    elif choice == "3":
        index = int(input("Enter the contact index to remove: "))
        remove_contact(index)
        print("Contact was removed successfully.")
    elif choice == "4":
        query = input("Enter the search query: ")
        search_contacts(query)       
    elif choice == "5":
        index = int(input("Enter the contact index to update: "))
        update_contact(index)
        print("Contact is updated successfully.")
    else:
        print("Exiting Contact Book Management System...")